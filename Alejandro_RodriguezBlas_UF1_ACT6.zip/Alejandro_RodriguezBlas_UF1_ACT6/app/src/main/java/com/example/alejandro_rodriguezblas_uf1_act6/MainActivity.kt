package com.example.alejandro_rodriguezblas_uf1_act6

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    lateinit var guardarButton : Button
    lateinit var plainText: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        guardarButton = findViewById(R.id.button)
        plainText = findViewById(R.id.editTextText)

        guardarButton.setOnClickListener{
            val duration = Toast.LENGTH_LONG
            val toast = Toast.makeText(this, plainText.text, duration)
            toast.show()
        }

    }
}